<?php

namespace FannoxNetwork;

class FannoxNetwork {
    // Add your additional methods here
}

?>